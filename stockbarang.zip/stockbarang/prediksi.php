<?php
require 'config.php';
requireLogin();

$pageTitle  = 'Prediksi Kebutuhan Stok';
$activeMenu = 'prediksi';

/**
 * "AI Sederhana": model statistik moving average, bukan machine learning.
 * Dihitung murni dari data transaksi Barang Keluar 30 hari terakhir.
 *
 * Rumus (lihat juga kartu penjelasan di halaman):
 *   H  = rentang hari data historis (maks. 30 hari, min. 1 hari)
 *   Q  = total qty Barang Keluar dalam 30 hari terakhir
 *   R  = Q / H                                   -> rata-rata keluar per hari
 *   P  = R x 30                                   -> proyeksi kebutuhan 30 hari ke depan
 *   D  = FLOOR(stok_saat_ini / R)                 -> estimasi hari sampai stok habis
 *   RR = MAX(0, CEIL(P + stok_minimum - stok_saat_ini)) -> rekomendasi jumlah restock
 */
$rows = $pdo->query(
    "SELECT b.idbarang, b.namabarang, b.satuan, b.stock, b.stock_minimum, b.created_at,
            COALESCE(SUM(CASE WHEN k.tanggal >= DATE_SUB(NOW(), INTERVAL 30 DAY) THEN k.qty ELSE 0 END), 0) AS keluar_30hari
     FROM barang b
     LEFT JOIN barang_keluar k ON k.idbarang = b.idbarang
     GROUP BY b.idbarang
     ORDER BY b.namabarang ASC"
)->fetchAll();

$prediksi = [];
foreach ($rows as $r) {
    $hariSejakDibuat = (int) floor((time() - strtotime($r['created_at'])) / 86400);
    $H = max(1, min(30, $hariSejakDibuat)); // rentang hari data
    $Q = (float) $r['keluar_30hari'];       // total keluar 30 hari

    $R = $Q / $H;          // rata-rata keluar / hari
    $P = $R * 30;           // proyeksi kebutuhan 30 hari ke depan

    if ($R <= 0) {
        $D = null;
        $status = 'nodata';
    } else {
        $D = (int) floor($r['stock'] / $R);
        if ($D <= 7) {
            $status = 'kritis';
        } elseif ($D <= 14) {
            $status = 'perhatian';
        } else {
            $status = 'aman';
        }
    }

    $RR = max(0, (int) ceil($P + $r['stock_minimum'] - $r['stock']));

    $prediksi[] = $r + [
        'H'                   => $H,
        'Q'                   => $Q,
        'rata_harian'         => round($R, 2),
        'proyeksi_30hari'     => (int) ceil($P),
        'proyeksi_raw'        => round($P, 2),
        'estimasi_habis_hari' => $D,
        'status'              => $status,
        'rekomendasi_restock' => $RR,
    ];
}

// Urutkan: paling kritis di atas
$prioritas = ['kritis' => 0, 'perhatian' => 1, 'aman' => 2, 'nodata' => 3];
usort($prediksi, fn($a, $b) => $prioritas[$a['status']] <=> $prioritas[$b['status']]);

$labelStatus = [
    'kritis'    => '<span class="badge badge-danger">Kritis</span>',
    'perhatian' => '<span class="badge badge-warning">Perhatian</span>',
    'aman'      => '<span class="badge badge-success">Aman</span>',
    'nodata'    => '<span class="badge badge-secondary">Belum Ada Histori</span>',
];

require 'partials/header.php';
?>

<!-- ===== Penjelasan Metode & Rumus ===== -->
<div class="card mb-4">
    <div class="card-header"><i class="fas fa-square-root-alt mr-1"></i>Metode &amp; Rumus Perhitungan</div>
    <div class="card-body">
        <p>
            Prediksi memakai model statistik sederhana <strong>rata-rata bergerak (moving average)</strong>
            berbasis histori transaksi <strong>Barang Keluar</strong> 30 hari terakhir — bukan machine
            learning, tapi cukup untuk memperkirakan kapan stok habis &amp; berapa jumlah restock yang disarankan.
        </p>
        <div class="table-responsive">
            <table class="table table-sm table-bordered mb-2">
                <thead class="thead-light">
                    <tr><th style="width:70px">Simbol</th><th>Rumus</th><th>Keterangan</th></tr>
                </thead>
                <tbody>
                    <tr>
                        <td><code>H</code></td>
                        <td><code>H = MIN(30, hari sejak barang tercatat)</code>, minimal 1</td>
                        <td>Rentang hari data historis yang dipakai</td>
                    </tr>
                    <tr>
                        <td><code>Q</code></td>
                        <td><code>Q = SUM(qty Barang Keluar)</code> dalam 30 hari terakhir</td>
                        <td>Total barang keluar pada rentang <code>H</code></td>
                    </tr>
                    <tr>
                        <td><code>R</code></td>
                        <td><code>R = Q &divide; H</code></td>
                        <td>Rata-rata pemakaian per hari</td>
                    </tr>
                    <tr>
                        <td><code>P</code></td>
                        <td><code>P = R &times; 30</code></td>
                        <td>Proyeksi kebutuhan 30 hari ke depan</td>
                    </tr>
                    <tr>
                        <td><code>D</code></td>
                        <td><code>D = FLOOR(Stok &divide; R)</code>, jika <code>R &gt; 0</code></td>
                        <td>Estimasi hari sampai stok habis</td>
                    </tr>
                    <tr>
                        <td><code>RR</code></td>
                        <td><code>RR = MAX(0, CEIL(P + Stok_Minimum &minus; Stok))</code></td>
                        <td>Rekomendasi jumlah restock</td>
                    </tr>
                </tbody>
            </table>
        </div>
        <p class="mb-0 small text-muted">
            Status: <span class="badge badge-danger">Kritis</span> jika D &le; 7 hari &middot;
            <span class="badge badge-warning">Perhatian</span> jika 7 &lt; D &le; 14 hari &middot;
            <span class="badge badge-success">Aman</span> jika D &gt; 14 hari &middot;
            <span class="badge badge-secondary">Belum Ada Histori</span> jika belum pernah ada transaksi keluar (R = 0).
            Klik tombol <b>Detail</b> pada tiap baris untuk melihat perhitungan lengkap dengan angka aslinya.
        </p>
    </div>
</div>

<div class="card mb-4">
    <div class="card-header"><i class="fas fa-chart-line mr-1"></i>Prediksi Kebutuhan Stok per Barang</div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>Nama Barang</th>
                        <th>Stok Saat Ini</th>
                        <th>Rata&sup2; Keluar/Hari (R)</th>
                        <th>Proyeksi 30 Hari (P)</th>
                        <th>Estimasi Stok Habis (D)</th>
                        <th>Rekomendasi Restock (RR)</th>
                        <th>Status</th>
                        <th>Detail</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($prediksi as $p): ?>
                    <tr>
                        <td><?= h($p['namabarang']) ?></td>
                        <td><?= $p['stock'] ?> <?= h($p['satuan']) ?></td>
                        <td><?= $p['rata_harian'] ?></td>
                        <td><?= $p['proyeksi_30hari'] ?> <?= h($p['satuan']) ?></td>
                        <td>
                            <?= $p['estimasi_habis_hari'] === null
                                ? '-'
                                : ($p['estimasi_habis_hari'] . ' hari lagi') ?>
                        </td>
                        <td>
                            <?= $p['rekomendasi_restock'] > 0
                                ? $p['rekomendasi_restock'] . ' ' . h($p['satuan'])
                                : '<span class="text-muted">Belum perlu</span>' ?>
                        </td>
                        <td><?= $labelStatus[$p['status']] ?></td>
                        <td>
                            <button type="button" class="btn btn-sm btn-outline-secondary" data-toggle="modal" data-target="#detail<?= $p['idbarang'] ?>">
                                <i class="fas fa-calculator"></i> Detail
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if (empty($prediksi)): ?>
                    <tr><td colspan="8" class="text-center text-muted">Belum ada data barang.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal detail perhitungan (di luar <table> supaya HTML tetap valid & DataTables tidak rusak) -->
<?php foreach ($prediksi as $p): ?>
<div class="modal fade" id="detail<?= $p['idbarang'] ?>">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Detail Perhitungan &mdash; <?= h($p['namabarang']) ?></h5>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <table class="table table-sm mb-0">
                    <tr>
                        <td>Rentang hari data (H)</td>
                        <td class="text-right"><code>H = <?= $p['H'] ?> hari</code></td>
                    </tr>
                    <tr>
                        <td>Total keluar 30 hari (Q)</td>
                        <td class="text-right"><code>Q = <?= (int) $p['Q'] ?> <?= h($p['satuan']) ?></code></td>
                    </tr>
                    <tr>
                        <td>Rata-rata keluar/hari</td>
                        <td class="text-right"><code>R = <?= (int) $p['Q'] ?> &divide; <?= $p['H'] ?> = <?= $p['rata_harian'] ?></code></td>
                    </tr>
                    <tr>
                        <td>Proyeksi 30 hari ke depan</td>
                        <td class="text-right"><code>P = <?= $p['rata_harian'] ?> &times; 30 = <?= $p['proyeksi_raw'] ?></code></td>
                    </tr>
                    <tr>
                        <td>Estimasi stok habis</td>
                        <td class="text-right">
                            <code><?php
                                echo $p['rata_harian'] > 0
                                    ? "D = FLOOR({$p['stock']} &divide; {$p['rata_harian']}) = {$p['estimasi_habis_hari']} hari"
                                    : 'R = 0 &rarr; tidak dapat diestimasi';
                            ?></code>
                        </td>
                    </tr>
                    <tr>
                        <td>Rekomendasi restock</td>
                        <td class="text-right">
                            <code>RR = MAX(0, CEIL(<?= $p['proyeksi_raw'] ?> + <?= $p['stock_minimum'] ?> &minus; <?= $p['stock'] ?>)) = <?= $p['rekomendasi_restock'] ?></code>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
</div>
<?php endforeach; ?>

<?php require 'partials/footer.php'; ?>
