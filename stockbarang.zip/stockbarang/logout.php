<?php
require 'config.php';

if (!empty($_SESSION['log'])) {
    logAktivitas($pdo, 'Logout', 'Keluar dari sistem');
}

$_SESSION = [];
session_destroy();
header('Location: login.php');
exit;
