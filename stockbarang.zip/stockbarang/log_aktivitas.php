<?php
require 'config.php';
requireLogin();

$pageTitle  = 'Log Aktifitas';
$activeMenu = 'log';

// Batasi 1000 baris terbaru supaya tabel tetap ringan.
$logs = $pdo->query(
    'SELECT id, nama_user, aktivitas, keterangan, waktu
     FROM log_aktivitas
     ORDER BY waktu DESC, id DESC
     LIMIT 1000'
)->fetchAll();

function badgeAktivitas(string $aktivitas): string
{
    $map = [
        'Login'               => 'badge-secondary',
        'Logout'               => 'badge-secondary',
        'Tambah Barang'        => 'badge-primary',
        'Update Barang'        => 'badge-warning',
        'Hapus Barang'         => 'badge-danger',
        'Barang Masuk'         => 'badge-success',
        'Update Barang Masuk'  => 'badge-warning',
        'Hapus Barang Masuk'   => 'badge-danger',
        'Barang Keluar'        => 'badge-info',
        'Update Barang Keluar' => 'badge-warning',
        'Hapus Barang Keluar'  => 'badge-danger',
    ];
    return $map[$aktivitas] ?? 'badge-light';
}

require 'partials/header.php';
?>

<div class="card mb-4">
    <div class="card-header">
        <i class="fas fa-history mr-1"></i>Riwayat Aktivitas (1000 terbaru)
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>Waktu</th>
                        <th>User</th>
                        <th>Aktivitas</th>
                        <th>Keterangan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($logs as $row): ?>
                    <tr>
                        <td><?= h($row['waktu']) ?></td>
                        <td><?= h($row['nama_user'] ?? '-') ?></td>
                        <td><span class="badge <?= badgeAktivitas($row['aktivitas']) ?>"><?= h($row['aktivitas']) ?></span></td>
                        <td><?= h($row['keterangan']) ?></td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if (empty($logs)): ?>
                    <tr><td colspan="4" class="text-center text-muted">Belum ada aktivitas tercatat.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require 'partials/footer.php'; ?>
