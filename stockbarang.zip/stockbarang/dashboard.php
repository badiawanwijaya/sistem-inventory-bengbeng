<?php
require 'config.php';
requireLogin();
require 'actions.php';

$pageTitle  = 'Dashboard';
$activeMenu = 'dashboard';

// ---------- Statistik ----------
$totalJenis = (int) $pdo->query('SELECT COUNT(*) FROM barang')->fetchColumn();
$totalStock = (int) $pdo->query('SELECT COALESCE(SUM(stock),0) FROM barang')->fetchColumn();
$totalHabis = (int) $pdo->query('SELECT COUNT(*) FROM barang WHERE stock <= 0')->fetchColumn();
$totalMenipis = (int) $pdo->query('SELECT COUNT(*) FROM barang WHERE stock > 0 AND stock <= stock_minimum')->fetchColumn();

// ---------- Grafik: barang masuk vs keluar, 6 bulan terakhir ----------
$bulanLabel = [];
$dataMasuk  = [];
$dataKeluar = [];

for ($i = 5; $i >= 0; $i--) {
    $ym = date('Y-m', strtotime("-$i month"));
    $bulanLabel[] = date('M Y', strtotime("-$i month"));

    $m = $pdo->prepare("SELECT COALESCE(SUM(qty),0) FROM barang_masuk WHERE DATE_FORMAT(tanggal, '%Y-%m') = ?");
    $m->execute([$ym]);
    $dataMasuk[] = (int) $m->fetchColumn();

    $k = $pdo->prepare("SELECT COALESCE(SUM(qty),0) FROM barang_keluar WHERE DATE_FORMAT(tanggal, '%Y-%m') = ?");
    $k->execute([$ym]);
    $dataKeluar[] = (int) $k->fetchColumn();
}

// ---------- Daftar barang stok kritis (untuk alert box) ----------
$kritis = $pdo->query(
    'SELECT idbarang, namabarang, stock, stock_minimum FROM barang WHERE stock <= stock_minimum ORDER BY stock ASC'
)->fetchAll();

// ---------- Daftar semua barang (tabel CRUD) ----------
$semuaBarang = $pdo->query('SELECT * FROM barang ORDER BY namabarang ASC')->fetchAll();

require 'partials/header.php';
?>

<!-- ===== Statistik Cards ===== -->
<div class="row">
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-primary shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Jenis Barang</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $totalJenis ?></div>
                    </div>
                    <div class="col-auto"><i class="fas fa-boxes fa-2x text-gray-300"></i></div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-info shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Total Stok</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $totalStock ?></div>
                    </div>
                    <div class="col-auto"><i class="fas fa-warehouse fa-2x text-gray-300"></i></div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-warning shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Stok Menipis</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $totalMenipis ?></div>
                    </div>
                    <div class="col-auto"><i class="fas fa-exclamation-triangle fa-2x text-gray-300"></i></div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-danger shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">Stok Habis</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $totalHabis ?></div>
                    </div>
                    <div class="col-auto"><i class="fas fa-times-circle fa-2x text-gray-300"></i></div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php if (!empty($kritis)): ?>
<div class="alert alert-warning">
    <strong><i class="fas fa-bell mr-1"></i>Perhatian:</strong>
    <?= count($kritis) ?> barang stoknya habis/menipis —
    <?php foreach ($kritis as $idx => $b): ?>
        <?= h($b['namabarang']) ?> (<?= $b['stock'] ?>)<?= $idx < count($kritis) - 1 ? ', ' : '' ?>
    <?php endforeach; ?>
</div>
<?php endif; ?>

<!-- ===== Grafik Barang Masuk vs Keluar ===== -->
<div class="card mb-4">
    <div class="card-header"><i class="fas fa-chart-bar mr-1"></i>Statistik Barang Masuk vs Keluar (6 Bulan Terakhir)</div>
    <div class="card-body">
        <canvas id="chartMasukKeluar" height="90"></canvas>
    </div>
</div>

<!-- ===== Data Barang ===== -->
<div class="card mb-4">
    <div class="card-header">
        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">
            <i class="fas fa-plus mr-1"></i>Tambah Barang
        </button>
        <a href="export.php" class="btn btn-info"><i class="fas fa-file-export mr-1"></i>Export Data</a>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Barang</th>
                        <th>Deskripsi</th>
                        <th>Satuan</th>
                        <th>Stock</th>
                        <th>Min. Stok</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i = 1; foreach ($semuaBarang as $data): ?>
                    <?php
                        $idb = $data['idbarang'];
                        if ($data['stock'] <= 0) {
                            $statusBadge = '<span class="badge badge-danger">Habis</span>';
                        } elseif ($data['stock'] <= $data['stock_minimum']) {
                            $statusBadge = '<span class="badge badge-warning">Menipis</span>';
                        } else {
                            $statusBadge = '<span class="badge badge-success">Aman</span>';
                        }
                    ?>
                    <tr>
                        <td><?= $i++ ?></td>
                        <td><?= h($data['namabarang']) ?></td>
                        <td><?= h($data['deskripsi']) ?></td>
                        <td><?= h($data['satuan']) ?></td>
                        <td><?= $data['stock'] ?></td>
                        <td><?= $data['stock_minimum'] ?></td>
                        <td><?= $statusBadge ?></td>
                        <td>
                            <button type="button" class="btn btn-warning" data-toggle="modal" data-target="#edit<?= $idb ?>">Edit</button>
                            <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#delete<?= $idb ?>">Delete</button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal Edit/Delete per barang (di luar <table> supaya HTML tetap valid & DataTables tidak rusak) -->
<?php foreach ($semuaBarang as $data): ?>
<?php $idb = $data['idbarang']; ?>
<div class="modal fade" id="edit<?= $idb ?>">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Edit Barang</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <form method="post">
                <div class="modal-body">
                    <label class="small mb-1">Nama Barang</label>
                    <input type="text" name="namabarang" value="<?= h($data['namabarang']) ?>" class="form-control" required>
                    <label class="small mb-1 mt-2">Deskripsi</label>
                    <input type="text" name="deskripsi" value="<?= h($data['deskripsi']) ?>" class="form-control">
                    <label class="small mb-1 mt-2">Satuan</label>
                    <input type="text" name="satuan" value="<?= h($data['satuan']) ?>" class="form-control">
                    <label class="small mb-1 mt-2">Stok Minimum (batas notifikasi)</label>
                    <input type="number" name="stock_minimum" value="<?= (int) $data['stock_minimum'] ?>" class="form-control" min="0" required>
                    <input type="hidden" name="idb" value="<?= $idb ?>">
                    <button type="submit" class="btn btn-primary mt-3" name="updatebarang">Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="delete<?= $idb ?>">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Hapus Barang?</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <form method="post">
                <div class="modal-body">
                    Apakah Anda yakin ingin menghapus <?= h($data['namabarang']) ?>? Semua riwayat masuk/keluar barang ini juga akan terhapus.
                    <input type="hidden" name="idb" value="<?= $idb ?>">
                    <br><br>
                    <button type="submit" class="btn btn-danger" name="hapusbarang">Hapus</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endforeach; ?>

<!-- Modal Tambah Barang -->
<div class="modal fade" id="myModal">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Tambah Barang</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <form method="post">
                <div class="modal-body">
                    <input type="text" name="namabarang" placeholder="Nama Barang" class="form-control" required>
                    <br>
                    <input type="text" name="deskripsi" placeholder="Deskripsi Barang" class="form-control">
                    <br>
                    <input type="text" name="satuan" placeholder="Satuan (Pcs, Rim, Box, ...)" class="form-control" value="Pcs">
                    <br>
                    <input type="number" name="stock" class="form-control" placeholder="Stock Awal" value="0" required>
                    <br>
                    <input type="number" name="stock_minimum" class="form-control" placeholder="Stok Minimum (batas notifikasi)" value="5" required>
                    <br>
                    <button type="submit" class="btn btn-primary" name="addnewbarang">Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php
$extraScripts = '
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
<script>
new Chart(document.getElementById("chartMasukKeluar"), {
    type: "bar",
    data: {
        labels: ' . json_encode($bulanLabel) . ',
        datasets: [
            { label: "Barang Masuk", backgroundColor: "#4e73df", data: ' . json_encode($dataMasuk) . ' },
            { label: "Barang Keluar", backgroundColor: "#e74a3b", data: ' . json_encode($dataKeluar) . ' }
        ]
    },
    options: { responsive: true, scales: { yAxes: [{ ticks: { beginAtZero: true } }] } }
});
</script>';
require 'partials/footer.php';
?>
