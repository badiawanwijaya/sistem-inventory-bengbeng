<?php
// Halaman utama sekarang ada di dashboard.php.
require 'config.php';
header('Location: ' . (empty($_SESSION['log']) ? 'login.php' : 'dashboard.php'));
exit;
