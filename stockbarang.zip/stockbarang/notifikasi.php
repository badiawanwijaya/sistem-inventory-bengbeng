<?php
/**
 * notifikasi.php
 * Endpoint JSON untuk notifikasi stok habis/menipis (dipoll via AJAX tiap 10 detik).
 */
require 'config.php';
requireLogin();

header('Content-Type: application/json');

$stmt = $pdo->query(
    'SELECT idbarang, namabarang, stock, stock_minimum
     FROM barang
     WHERE stock <= stock_minimum
     ORDER BY stock ASC, namabarang ASC'
);
$items = $stmt->fetchAll();

$result = array_map(function ($row) {
    return [
        'id'     => (int) $row['idbarang'],
        'nama'   => $row['namabarang'],
        'stock'  => (int) $row['stock'],
        'minimum'=> (int) $row['stock_minimum'],
        'status' => $row['stock'] <= 0 ? 'habis' : 'menipis',
    ];
}, $items);

echo json_encode([
    'count' => count($result),
    'items' => $result,
]);
