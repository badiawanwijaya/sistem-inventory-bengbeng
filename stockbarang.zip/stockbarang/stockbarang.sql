-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 05 Agu 2026 pada 13.51
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `stockbarang`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `barang`
--

CREATE TABLE `barang` (
  `idbarang` int(10) UNSIGNED NOT NULL,
  `namabarang` varchar(150) NOT NULL,
  `deskripsi` varchar(255) DEFAULT NULL,
  `satuan` varchar(30) NOT NULL DEFAULT 'Pcs',
  `stock` int(11) NOT NULL DEFAULT 0,
  `stock_minimum` int(11) NOT NULL DEFAULT 5,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `barang`
--

INSERT INTO `barang` (`idbarang`, `namabarang`, `deskripsi`, `satuan`, `stock`, `stock_minimum`, `created_at`, `updated_at`) VALUES
(1, 'Kertas A4 80gr', 'Sinar Dunia', 'Rim', 168, 20, '2026-06-08 05:35:28', '2026-08-05 10:35:28'),
(2, 'Kertas F4 80gr', 'Sinar Dunia', 'Rim', 179, 20, '2026-05-27 05:35:28', '2026-08-05 10:35:28'),
(3, 'Kertas A3 80gr', 'Sinar Dunia', 'Rim', 104, 10, '2026-05-30 05:35:28', '2026-08-05 10:35:28'),
(4, 'Kertas Foto Glossy', 'A4 230gsm', 'Pack', 169, 5, '2026-06-11 05:35:28', '2026-08-05 10:35:28'),
(5, 'Tinta Printer Hitam', 'Epson 003 Black', 'Botol', 142, 8, '2026-06-08 05:35:28', '2026-08-05 10:35:28'),
(6, 'Tinta Printer Warna', 'Epson 003 Color', 'Botol', 115, 8, '2026-05-27 05:35:28', '2026-08-05 10:35:28'),
(7, 'Toner Laser Hitam', 'Canon 12A', 'Unit', 108, 3, '2026-05-27 05:35:28', '2026-08-05 10:35:28'),
(8, 'Stapler Besar', 'Kenko HD-50', 'Pcs', 127, 5, '2026-06-10 05:35:28', '2026-08-05 10:35:28'),
(9, 'Isi Staples No.10', 'Kenko', 'Box', 244, 15, '2026-06-14 05:35:28', '2026-08-05 10:35:28'),
(10, 'Map Plastik', 'Bantex', 'Pcs', 180, 20, '2026-05-27 05:35:28', '2026-08-05 10:35:28'),
(11, 'Amplop Coklat Polos', 'Ukuran folio', 'Pack', 167, 10, '2026-06-06 05:35:28', '2026-08-05 10:35:28'),
(12, 'Spidol Whiteboard', 'Snowman Hitam', 'Pcs', 94, 15, '2026-06-12 05:35:28', '2026-08-05 10:35:28'),
(13, 'Pulpen Standard', 'Standard AE7', 'Pcs', 191, 30, '2026-05-31 05:35:28', '2026-08-05 10:35:28'),
(14, 'Penghapus Pensil', 'Joyko', 'Pcs', 60, 20, '2026-05-27 05:35:28', '2026-08-05 10:35:28'),
(15, 'Lakban Bening', 'Daimaru 2 inch', 'Pcs', 119, 10, '2026-05-31 05:35:28', '2026-08-05 10:35:28'),
(16, 'Gunting', 'Kenko S-168', 'Pcs', 140, 8, '2026-05-31 05:35:28', '2026-08-05 10:35:28'),
(17, 'Plastik Laminating A4', 'Standard 125 micron', 'Pack', 167, 5, '2026-05-27 05:35:28', '2026-08-05 10:35:28'),
(18, 'Buku Kwitansi', 'Isi 50 lembar', 'Pcs', 118, 10, '2026-05-29 05:35:28', '2026-08-05 10:35:28'),
(19, 'Klip Kertas', 'No. 5', 'Box', 130, 20, '2026-06-13 05:35:28', '2026-08-05 10:35:28'),
(20, 'Binder Clip Besar', 'No. 200', 'Box', 187, 10, '2026-06-21 05:35:28', '2026-08-05 10:35:28');

-- --------------------------------------------------------

--
-- Struktur dari tabel `barang_keluar`
--

CREATE TABLE `barang_keluar` (
  `idkeluar` int(10) UNSIGNED NOT NULL,
  `idbarang` int(10) UNSIGNED NOT NULL,
  `tanggal` datetime NOT NULL DEFAULT current_timestamp(),
  `qty` int(11) NOT NULL,
  `penerima` varchar(150) DEFAULT NULL,
  `user_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `barang_keluar`
--

INSERT INTO `barang_keluar` (`idkeluar`, `idbarang`, `tanggal`, `qty`, `penerima`, `user_id`) VALUES
(1, 1, '2026-06-29 22:35:38', 38, 'Pelanggan', 1),
(2, 1, '2026-07-15 22:44:30', 25, 'Ruang Rapat', 1),
(3, 1, '2026-07-27 01:48:21', 5, 'Admin Kantor', 1),
(4, 1, '2026-08-01 20:09:23', 30, 'Divisi Keuangan', 1),
(5, 2, '2026-05-30 04:03:03', 28, 'Ruang Rapat', 1),
(6, 2, '2026-06-17 02:28:54', 40, 'Divisi HRD', 1),
(7, 2, '2026-06-18 00:57:42', 10, 'Front Office', 1),
(8, 3, '2026-06-02 23:48:54', 2, 'Divisi Keuangan', 1),
(9, 3, '2026-07-16 23:17:21', 26, 'Admin Kantor', 1),
(10, 4, '2026-07-01 03:07:47', 6, 'Ruang Rapat', 1),
(11, 4, '2026-07-23 23:09:00', 34, 'Divisi Marketing', 1),
(12, 5, '2026-06-16 21:20:32', 25, 'Ruang Rapat', 1),
(13, 5, '2026-07-14 22:58:27', 16, 'Divisi Marketing', 1),
(14, 5, '2026-07-23 00:17:26', 7, 'Ruang Rapat', 1),
(15, 5, '2026-07-30 23:06:34', 1, 'Bagian Umum', 1),
(16, 6, '2026-06-23 04:06:42', 12, 'Front Office', 1),
(17, 6, '2026-06-28 21:00:57', 14, 'Divisi Keuangan', 1),
(18, 6, '2026-07-10 00:17:56', 30, 'Bagian Umum', 1),
(19, 6, '2026-07-13 03:28:24', 1, 'Bagian Umum', 1),
(20, 7, '2026-07-18 20:39:31', 24, 'Pelanggan', 1),
(21, 7, '2026-07-23 22:27:56', 22, 'Front Office', 1),
(22, 8, '2026-07-14 01:57:48', 33, 'Front Office', 1),
(23, 8, '2026-07-21 21:28:01', 40, 'Divisi HRD', 1),
(24, 9, '2026-06-22 19:39:47', 3, 'Divisi Marketing', 1),
(25, 9, '2026-07-16 02:09:38', 36, 'Divisi Keuangan', 1),
(26, 9, '2026-07-27 02:23:44', 21, 'Ruang Rapat', 1),
(27, 9, '2026-08-01 01:48:16', 26, 'Ruang Rapat', 1),
(28, 10, '2026-06-12 00:48:37', 35, 'Ruang Rapat', 1),
(29, 10, '2026-06-16 23:02:02', 5, 'Admin Kantor', 1),
(30, 10, '2026-07-16 03:10:55', 17, 'Pelanggan', 1),
(31, 10, '2026-07-29 02:57:30', 15, 'Bagian Umum', 1),
(32, 11, '2026-06-27 03:43:50', 1, 'Front Office', 1),
(33, 11, '2026-08-02 20:24:51', 2, 'Divisi HRD', 1),
(34, 12, '2026-06-14 20:22:06', 8, 'Bagian Umum', 1),
(35, 12, '2026-07-27 03:07:04', 31, 'Bagian Umum', 1),
(36, 12, '2026-07-29 01:29:36', 1, 'Divisi Keuangan', 1),
(37, 13, '2026-07-06 01:53:08', 10, 'Divisi HRD', 1),
(38, 13, '2026-07-27 23:44:24', 21, 'Pelanggan', 1),
(39, 14, '2026-06-05 21:35:07', 8, 'Ruang Rapat', 1),
(40, 14, '2026-06-19 20:07:57', 7, 'Front Office', 1),
(41, 14, '2026-07-01 03:01:54', 7, 'Divisi Marketing', 1),
(42, 14, '2026-07-16 23:10:05', 17, 'Front Office', 1),
(43, 15, '2026-06-24 03:08:55', 14, 'Divisi Keuangan', 1),
(44, 15, '2026-07-15 03:59:44', 34, 'Divisi Keuangan', 1),
(45, 15, '2026-07-28 19:58:45', 21, 'Divisi Marketing', 1),
(46, 15, '2026-07-30 04:35:12', 40, 'Front Office', 1),
(47, 16, '2026-06-04 03:32:45', 38, 'Divisi HRD', 1),
(48, 16, '2026-07-02 22:05:29', 21, 'Ruang Rapat', 1),
(49, 16, '2026-07-12 20:54:40', 24, 'Bagian Umum', 1),
(50, 17, '2026-07-04 03:15:26', 33, 'Bagian Umum', 1),
(51, 17, '2026-08-01 00:10:31', 31, 'Divisi Keuangan', 1),
(52, 18, '2026-06-14 03:37:49', 5, 'Pelanggan', 1),
(53, 18, '2026-06-17 20:09:33', 29, 'Admin Kantor', 1),
(54, 18, '2026-07-23 04:12:34', 13, 'Admin Kantor', 1),
(55, 19, '2026-07-03 22:28:12', 20, 'Bagian Umum', 1),
(56, 19, '2026-07-18 21:47:45', 33, 'Divisi HRD', 1),
(57, 20, '2026-06-26 02:53:27', 40, 'Divisi Keuangan', 1),
(58, 20, '2026-07-17 22:51:38', 8, 'Pelanggan', 1),
(59, 20, '2026-07-18 00:34:37', 34, 'Ruang Rapat', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `barang_masuk`
--

CREATE TABLE `barang_masuk` (
  `idmasuk` int(10) UNSIGNED NOT NULL,
  `idbarang` int(10) UNSIGNED NOT NULL,
  `tanggal` datetime NOT NULL DEFAULT current_timestamp(),
  `qty` int(11) NOT NULL,
  `keterangan` varchar(255) DEFAULT NULL,
  `user_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `barang_masuk`
--

INSERT INTO `barang_masuk` (`idmasuk`, `idbarang`, `tanggal`, `qty`, `keterangan`, `user_id`) VALUES
(1, 1, '2026-06-08 13:47:41', 216, 'Stok awal - CV Sinar Abadi', 1),
(2, 1, '2026-07-03 22:19:14', 50, 'Restock - Toko ATK Makmur', 1),
(3, 2, '2026-05-27 14:24:47', 181, 'Stok awal - Distributor Tinta Jaya', 1),
(4, 2, '2026-07-04 22:35:46', 76, 'Restock - Grosir Kantor Sejahtera', 1),
(5, 3, '2026-05-30 14:18:32', 94, 'Stok awal - Grosir Kantor Sejahtera', 1),
(6, 3, '2026-07-29 01:45:19', 38, 'Restock - PT Papertama', 1),
(7, 4, '2026-06-11 14:19:59', 135, 'Stok awal - CV Sinar Abadi', 1),
(8, 4, '2026-06-28 23:22:03', 74, 'Restock - Toko ATK Makmur', 1),
(9, 5, '2026-06-08 14:20:23', 121, 'Stok awal - Toko ATK Makmur', 1),
(10, 5, '2026-07-29 23:13:28', 70, 'Restock - Toko ATK Makmur', 1),
(11, 6, '2026-05-27 14:13:36', 152, 'Stok awal - Distributor Tinta Jaya', 1),
(12, 6, '2026-07-26 20:24:43', 20, 'Restock - Grosir Kantor Sejahtera', 1),
(13, 7, '2026-05-27 13:59:22', 154, 'Stok awal - Grosir Kantor Sejahtera', 1),
(14, 8, '2026-06-10 13:39:39', 172, 'Stok awal - PT Papertama', 1),
(15, 8, '2026-06-16 04:14:42', 28, 'Restock - Distributor Tinta Jaya', 1),
(16, 9, '2026-06-14 14:17:29', 250, 'Stok awal - Grosir Kantor Sejahtera', 1),
(17, 9, '2026-07-09 21:32:01', 80, 'Restock - Grosir Kantor Sejahtera', 1),
(18, 10, '2026-05-27 14:25:32', 225, 'Stok awal - Grosir Kantor Sejahtera', 1),
(19, 10, '2026-07-02 01:51:30', 27, 'Restock - Distributor Tinta Jaya', 1),
(20, 11, '2026-06-06 14:19:57', 170, 'Stok awal - CV Sinar Abadi', 1),
(21, 12, '2026-06-12 13:56:37', 104, 'Stok awal - Toko ATK Makmur', 1),
(22, 12, '2026-07-22 23:32:07', 30, 'Restock - Distributor Tinta Jaya', 1),
(23, 13, '2026-05-31 14:23:14', 153, 'Stok awal - CV Sinar Abadi', 1),
(24, 13, '2026-07-28 03:42:25', 69, 'Restock - Distributor Tinta Jaya', 1),
(25, 14, '2026-05-27 14:19:28', 99, 'Stok awal - Distributor Tinta Jaya', 1),
(26, 15, '2026-05-31 14:20:24', 228, 'Stok awal - Distributor Tinta Jaya', 1),
(27, 16, '2026-05-31 13:42:33', 144, 'Stok awal - CV Sinar Abadi', 1),
(28, 16, '2026-07-29 01:47:08', 79, 'Restock - Toko ATK Makmur', 1),
(29, 17, '2026-05-27 14:19:29', 199, 'Stok awal - Distributor Tinta Jaya', 1),
(30, 17, '2026-07-24 04:14:11', 32, 'Restock - CV Sinar Abadi', 1),
(31, 18, '2026-05-29 14:27:45', 107, 'Stok awal - Toko ATK Makmur', 1),
(32, 18, '2026-06-23 20:33:08', 58, 'Restock - Distributor Tinta Jaya', 1),
(33, 19, '2026-06-13 14:26:33', 122, 'Stok awal - Grosir Kantor Sejahtera', 1),
(34, 19, '2026-06-28 00:22:23', 61, 'Restock - CV Sinar Abadi', 1),
(35, 20, '2026-06-21 14:27:21', 212, 'Stok awal - CV Sinar Abadi', 1),
(36, 20, '2026-07-20 01:20:54', 57, 'Restock - Grosir Kantor Sejahtera', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `log_aktivitas`
--

CREATE TABLE `log_aktivitas` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED DEFAULT NULL,
  `nama_user` varchar(100) DEFAULT NULL,
  `aktivitas` varchar(50) NOT NULL,
  `keterangan` varchar(255) DEFAULT NULL,
  `waktu` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `log_aktivitas`
--

INSERT INTO `log_aktivitas` (`id`, `user_id`, `nama_user`, `aktivitas`, `keterangan`, `waktu`) VALUES
(1, 1, 'Admin Lab', 'Tambah Barang', 'Menambah barang \"Kertas A4 80gr\" (stok awal via seeding)', '2026-06-08 12:35:28'),
(2, 1, 'Admin Lab', 'Barang Masuk', 'Menambah stok \"Kertas A4 80gr\" sebanyak 216 (Stok awal)', '2026-06-08 13:47:41'),
(3, 1, 'Admin Lab', 'Barang Keluar', 'Mengeluarkan \"Kertas A4 80gr\" sebanyak 38 untuk Pelanggan', '2026-06-29 22:35:38'),
(4, 1, 'Admin Lab', 'Barang Masuk', 'Menambah stok \"Kertas A4 80gr\" sebanyak 50 (Restock)', '2026-07-03 22:19:14'),
(5, 1, 'Admin Lab', 'Barang Keluar', 'Mengeluarkan \"Kertas A4 80gr\" sebanyak 25 untuk Ruang Rapat', '2026-07-15 22:44:30'),
(6, 1, 'Admin Lab', 'Barang Keluar', 'Mengeluarkan \"Kertas A4 80gr\" sebanyak 5 untuk Admin Kantor', '2026-07-27 01:48:21'),
(7, 1, 'Admin Lab', 'Barang Keluar', 'Mengeluarkan \"Kertas A4 80gr\" sebanyak 30 untuk Divisi Keuangan', '2026-08-01 20:09:23'),
(8, 1, 'Admin Lab', 'Tambah Barang', 'Menambah barang \"Kertas F4 80gr\" (stok awal via seeding)', '2026-05-27 12:35:28'),
(9, 1, 'Admin Lab', 'Barang Masuk', 'Menambah stok \"Kertas F4 80gr\" sebanyak 181 (Stok awal)', '2026-05-27 14:24:47'),
(10, 1, 'Admin Lab', 'Barang Keluar', 'Mengeluarkan \"Kertas F4 80gr\" sebanyak 28 untuk Ruang Rapat', '2026-05-30 04:03:03'),
(11, 1, 'Admin Lab', 'Barang Keluar', 'Mengeluarkan \"Kertas F4 80gr\" sebanyak 40 untuk Divisi HRD', '2026-06-17 02:28:54'),
(12, 1, 'Admin Lab', 'Barang Keluar', 'Mengeluarkan \"Kertas F4 80gr\" sebanyak 10 untuk Front Office', '2026-06-18 00:57:42'),
(13, 1, 'Admin Lab', 'Barang Masuk', 'Menambah stok \"Kertas F4 80gr\" sebanyak 76 (Restock)', '2026-07-04 22:35:46'),
(14, 1, 'Admin Lab', 'Tambah Barang', 'Menambah barang \"Kertas A3 80gr\" (stok awal via seeding)', '2026-05-30 12:35:28'),
(15, 1, 'Admin Lab', 'Barang Masuk', 'Menambah stok \"Kertas A3 80gr\" sebanyak 94 (Stok awal)', '2026-05-30 14:18:32'),
(16, 1, 'Admin Lab', 'Barang Keluar', 'Mengeluarkan \"Kertas A3 80gr\" sebanyak 2 untuk Divisi Keuangan', '2026-06-02 23:48:54'),
(17, 1, 'Admin Lab', 'Barang Keluar', 'Mengeluarkan \"Kertas A3 80gr\" sebanyak 26 untuk Admin Kantor', '2026-07-16 23:17:21'),
(18, 1, 'Admin Lab', 'Barang Masuk', 'Menambah stok \"Kertas A3 80gr\" sebanyak 38 (Restock)', '2026-07-29 01:45:19'),
(19, 1, 'Admin Lab', 'Tambah Barang', 'Menambah barang \"Kertas Foto Glossy\" (stok awal via seeding)', '2026-06-11 12:35:28'),
(20, 1, 'Admin Lab', 'Barang Masuk', 'Menambah stok \"Kertas Foto Glossy\" sebanyak 135 (Stok awal)', '2026-06-11 14:19:59'),
(21, 1, 'Admin Lab', 'Barang Masuk', 'Menambah stok \"Kertas Foto Glossy\" sebanyak 74 (Restock)', '2026-06-28 23:22:03'),
(22, 1, 'Admin Lab', 'Barang Keluar', 'Mengeluarkan \"Kertas Foto Glossy\" sebanyak 6 untuk Ruang Rapat', '2026-07-01 03:07:47'),
(23, 1, 'Admin Lab', 'Barang Keluar', 'Mengeluarkan \"Kertas Foto Glossy\" sebanyak 34 untuk Divisi Marketing', '2026-07-23 23:09:00'),
(24, 1, 'Admin Lab', 'Tambah Barang', 'Menambah barang \"Tinta Printer Hitam\" (stok awal via seeding)', '2026-06-08 12:35:28'),
(25, 1, 'Admin Lab', 'Barang Masuk', 'Menambah stok \"Tinta Printer Hitam\" sebanyak 121 (Stok awal)', '2026-06-08 14:20:23'),
(26, 1, 'Admin Lab', 'Barang Keluar', 'Mengeluarkan \"Tinta Printer Hitam\" sebanyak 25 untuk Ruang Rapat', '2026-06-16 21:20:32'),
(27, 1, 'Admin Lab', 'Barang Keluar', 'Mengeluarkan \"Tinta Printer Hitam\" sebanyak 16 untuk Divisi Marketing', '2026-07-14 22:58:27'),
(28, 1, 'Admin Lab', 'Barang Keluar', 'Mengeluarkan \"Tinta Printer Hitam\" sebanyak 7 untuk Ruang Rapat', '2026-07-23 00:17:26'),
(29, 1, 'Admin Lab', 'Barang Masuk', 'Menambah stok \"Tinta Printer Hitam\" sebanyak 70 (Restock)', '2026-07-29 23:13:28'),
(30, 1, 'Admin Lab', 'Barang Keluar', 'Mengeluarkan \"Tinta Printer Hitam\" sebanyak 1 untuk Bagian Umum', '2026-07-30 23:06:34'),
(31, 1, 'Admin Lab', 'Tambah Barang', 'Menambah barang \"Tinta Printer Warna\" (stok awal via seeding)', '2026-05-27 12:35:28'),
(32, 1, 'Admin Lab', 'Barang Masuk', 'Menambah stok \"Tinta Printer Warna\" sebanyak 152 (Stok awal)', '2026-05-27 14:13:36'),
(33, 1, 'Admin Lab', 'Barang Keluar', 'Mengeluarkan \"Tinta Printer Warna\" sebanyak 12 untuk Front Office', '2026-06-23 04:06:42'),
(34, 1, 'Admin Lab', 'Barang Keluar', 'Mengeluarkan \"Tinta Printer Warna\" sebanyak 14 untuk Divisi Keuangan', '2026-06-28 21:00:57'),
(35, 1, 'Admin Lab', 'Barang Keluar', 'Mengeluarkan \"Tinta Printer Warna\" sebanyak 30 untuk Bagian Umum', '2026-07-10 00:17:56'),
(36, 1, 'Admin Lab', 'Barang Keluar', 'Mengeluarkan \"Tinta Printer Warna\" sebanyak 1 untuk Bagian Umum', '2026-07-13 03:28:24'),
(37, 1, 'Admin Lab', 'Barang Masuk', 'Menambah stok \"Tinta Printer Warna\" sebanyak 20 (Restock)', '2026-07-26 20:24:43'),
(38, 1, 'Admin Lab', 'Tambah Barang', 'Menambah barang \"Toner Laser Hitam\" (stok awal via seeding)', '2026-05-27 12:35:28'),
(39, 1, 'Admin Lab', 'Barang Masuk', 'Menambah stok \"Toner Laser Hitam\" sebanyak 154 (Stok awal)', '2026-05-27 13:59:22'),
(40, 1, 'Admin Lab', 'Barang Keluar', 'Mengeluarkan \"Toner Laser Hitam\" sebanyak 24 untuk Pelanggan', '2026-07-18 20:39:31'),
(41, 1, 'Admin Lab', 'Barang Keluar', 'Mengeluarkan \"Toner Laser Hitam\" sebanyak 22 untuk Front Office', '2026-07-23 22:27:56'),
(42, 1, 'Admin Lab', 'Tambah Barang', 'Menambah barang \"Stapler Besar\" (stok awal via seeding)', '2026-06-10 12:35:28'),
(43, 1, 'Admin Lab', 'Barang Masuk', 'Menambah stok \"Stapler Besar\" sebanyak 172 (Stok awal)', '2026-06-10 13:39:39'),
(44, 1, 'Admin Lab', 'Barang Masuk', 'Menambah stok \"Stapler Besar\" sebanyak 28 (Restock)', '2026-06-16 04:14:42'),
(45, 1, 'Admin Lab', 'Barang Keluar', 'Mengeluarkan \"Stapler Besar\" sebanyak 33 untuk Front Office', '2026-07-14 01:57:48'),
(46, 1, 'Admin Lab', 'Barang Keluar', 'Mengeluarkan \"Stapler Besar\" sebanyak 40 untuk Divisi HRD', '2026-07-21 21:28:01'),
(47, 1, 'Admin Lab', 'Tambah Barang', 'Menambah barang \"Isi Staples No.10\" (stok awal via seeding)', '2026-06-14 12:35:28'),
(48, 1, 'Admin Lab', 'Barang Masuk', 'Menambah stok \"Isi Staples No.10\" sebanyak 250 (Stok awal)', '2026-06-14 14:17:29'),
(49, 1, 'Admin Lab', 'Barang Keluar', 'Mengeluarkan \"Isi Staples No.10\" sebanyak 3 untuk Divisi Marketing', '2026-06-22 19:39:47'),
(50, 1, 'Admin Lab', 'Barang Masuk', 'Menambah stok \"Isi Staples No.10\" sebanyak 80 (Restock)', '2026-07-09 21:32:01'),
(51, 1, 'Admin Lab', 'Barang Keluar', 'Mengeluarkan \"Isi Staples No.10\" sebanyak 36 untuk Divisi Keuangan', '2026-07-16 02:09:38'),
(52, 1, 'Admin Lab', 'Barang Keluar', 'Mengeluarkan \"Isi Staples No.10\" sebanyak 21 untuk Ruang Rapat', '2026-07-27 02:23:44'),
(53, 1, 'Admin Lab', 'Barang Keluar', 'Mengeluarkan \"Isi Staples No.10\" sebanyak 26 untuk Ruang Rapat', '2026-08-01 01:48:16'),
(54, 1, 'Admin Lab', 'Tambah Barang', 'Menambah barang \"Map Plastik\" (stok awal via seeding)', '2026-05-27 12:35:28'),
(55, 1, 'Admin Lab', 'Barang Masuk', 'Menambah stok \"Map Plastik\" sebanyak 225 (Stok awal)', '2026-05-27 14:25:32'),
(56, 1, 'Admin Lab', 'Barang Keluar', 'Mengeluarkan \"Map Plastik\" sebanyak 35 untuk Ruang Rapat', '2026-06-12 00:48:37'),
(57, 1, 'Admin Lab', 'Barang Keluar', 'Mengeluarkan \"Map Plastik\" sebanyak 5 untuk Admin Kantor', '2026-06-16 23:02:02'),
(58, 1, 'Admin Lab', 'Barang Masuk', 'Menambah stok \"Map Plastik\" sebanyak 27 (Restock)', '2026-07-02 01:51:30'),
(59, 1, 'Admin Lab', 'Barang Keluar', 'Mengeluarkan \"Map Plastik\" sebanyak 17 untuk Pelanggan', '2026-07-16 03:10:55'),
(60, 1, 'Admin Lab', 'Barang Keluar', 'Mengeluarkan \"Map Plastik\" sebanyak 15 untuk Bagian Umum', '2026-07-29 02:57:30'),
(61, 1, 'Admin Lab', 'Tambah Barang', 'Menambah barang \"Amplop Coklat Polos\" (stok awal via seeding)', '2026-06-06 12:35:28'),
(62, 1, 'Admin Lab', 'Barang Masuk', 'Menambah stok \"Amplop Coklat Polos\" sebanyak 170 (Stok awal)', '2026-06-06 14:19:57'),
(63, 1, 'Admin Lab', 'Barang Keluar', 'Mengeluarkan \"Amplop Coklat Polos\" sebanyak 1 untuk Front Office', '2026-06-27 03:43:50'),
(64, 1, 'Admin Lab', 'Barang Keluar', 'Mengeluarkan \"Amplop Coklat Polos\" sebanyak 2 untuk Divisi HRD', '2026-08-02 20:24:51'),
(65, 1, 'Admin Lab', 'Tambah Barang', 'Menambah barang \"Spidol Whiteboard\" (stok awal via seeding)', '2026-06-12 12:35:28'),
(66, 1, 'Admin Lab', 'Barang Masuk', 'Menambah stok \"Spidol Whiteboard\" sebanyak 104 (Stok awal)', '2026-06-12 13:56:37'),
(67, 1, 'Admin Lab', 'Barang Keluar', 'Mengeluarkan \"Spidol Whiteboard\" sebanyak 8 untuk Bagian Umum', '2026-06-14 20:22:06'),
(68, 1, 'Admin Lab', 'Barang Masuk', 'Menambah stok \"Spidol Whiteboard\" sebanyak 30 (Restock)', '2026-07-22 23:32:07'),
(69, 1, 'Admin Lab', 'Barang Keluar', 'Mengeluarkan \"Spidol Whiteboard\" sebanyak 31 untuk Bagian Umum', '2026-07-27 03:07:04'),
(70, 1, 'Admin Lab', 'Barang Keluar', 'Mengeluarkan \"Spidol Whiteboard\" sebanyak 1 untuk Divisi Keuangan', '2026-07-29 01:29:36'),
(71, 1, 'Admin Lab', 'Tambah Barang', 'Menambah barang \"Pulpen Standard\" (stok awal via seeding)', '2026-05-31 12:35:28'),
(72, 1, 'Admin Lab', 'Barang Masuk', 'Menambah stok \"Pulpen Standard\" sebanyak 153 (Stok awal)', '2026-05-31 14:23:14'),
(73, 1, 'Admin Lab', 'Barang Keluar', 'Mengeluarkan \"Pulpen Standard\" sebanyak 10 untuk Divisi HRD', '2026-07-06 01:53:08'),
(74, 1, 'Admin Lab', 'Barang Masuk', 'Menambah stok \"Pulpen Standard\" sebanyak 69 (Restock)', '2026-07-28 03:42:25'),
(75, 1, 'Admin Lab', 'Barang Keluar', 'Mengeluarkan \"Pulpen Standard\" sebanyak 21 untuk Pelanggan', '2026-07-27 23:44:24'),
(76, 1, 'Admin Lab', 'Tambah Barang', 'Menambah barang \"Penghapus Pensil\" (stok awal via seeding)', '2026-05-27 12:35:28'),
(77, 1, 'Admin Lab', 'Barang Masuk', 'Menambah stok \"Penghapus Pensil\" sebanyak 99 (Stok awal)', '2026-05-27 14:19:28'),
(78, 1, 'Admin Lab', 'Barang Keluar', 'Mengeluarkan \"Penghapus Pensil\" sebanyak 8 untuk Ruang Rapat', '2026-06-05 21:35:07'),
(79, 1, 'Admin Lab', 'Barang Keluar', 'Mengeluarkan \"Penghapus Pensil\" sebanyak 7 untuk Front Office', '2026-06-19 20:07:57'),
(80, 1, 'Admin Lab', 'Barang Keluar', 'Mengeluarkan \"Penghapus Pensil\" sebanyak 7 untuk Divisi Marketing', '2026-07-01 03:01:54'),
(81, 1, 'Admin Lab', 'Barang Keluar', 'Mengeluarkan \"Penghapus Pensil\" sebanyak 17 untuk Front Office', '2026-07-16 23:10:05'),
(82, 1, 'Admin Lab', 'Tambah Barang', 'Menambah barang \"Lakban Bening\" (stok awal via seeding)', '2026-05-31 12:35:28'),
(83, 1, 'Admin Lab', 'Barang Masuk', 'Menambah stok \"Lakban Bening\" sebanyak 228 (Stok awal)', '2026-05-31 14:20:24'),
(84, 1, 'Admin Lab', 'Barang Keluar', 'Mengeluarkan \"Lakban Bening\" sebanyak 14 untuk Divisi Keuangan', '2026-06-24 03:08:55'),
(85, 1, 'Admin Lab', 'Barang Keluar', 'Mengeluarkan \"Lakban Bening\" sebanyak 34 untuk Divisi Keuangan', '2026-07-15 03:59:44'),
(86, 1, 'Admin Lab', 'Barang Keluar', 'Mengeluarkan \"Lakban Bening\" sebanyak 21 untuk Divisi Marketing', '2026-07-28 19:58:45'),
(87, 1, 'Admin Lab', 'Barang Keluar', 'Mengeluarkan \"Lakban Bening\" sebanyak 40 untuk Front Office', '2026-07-30 04:35:12'),
(88, 1, 'Admin Lab', 'Tambah Barang', 'Menambah barang \"Gunting\" (stok awal via seeding)', '2026-05-31 12:35:28'),
(89, 1, 'Admin Lab', 'Barang Masuk', 'Menambah stok \"Gunting\" sebanyak 144 (Stok awal)', '2026-05-31 13:42:33'),
(90, 1, 'Admin Lab', 'Barang Keluar', 'Mengeluarkan \"Gunting\" sebanyak 38 untuk Divisi HRD', '2026-06-04 03:32:45'),
(91, 1, 'Admin Lab', 'Barang Keluar', 'Mengeluarkan \"Gunting\" sebanyak 21 untuk Ruang Rapat', '2026-07-02 22:05:29'),
(92, 1, 'Admin Lab', 'Barang Keluar', 'Mengeluarkan \"Gunting\" sebanyak 24 untuk Bagian Umum', '2026-07-12 20:54:40'),
(93, 1, 'Admin Lab', 'Barang Masuk', 'Menambah stok \"Gunting\" sebanyak 79 (Restock)', '2026-07-29 01:47:08'),
(94, 1, 'Admin Lab', 'Tambah Barang', 'Menambah barang \"Plastik Laminating A4\" (stok awal via seeding)', '2026-05-27 12:35:28'),
(95, 1, 'Admin Lab', 'Barang Masuk', 'Menambah stok \"Plastik Laminating A4\" sebanyak 199 (Stok awal)', '2026-05-27 14:19:29'),
(96, 1, 'Admin Lab', 'Barang Keluar', 'Mengeluarkan \"Plastik Laminating A4\" sebanyak 33 untuk Bagian Umum', '2026-07-04 03:15:26'),
(97, 1, 'Admin Lab', 'Barang Masuk', 'Menambah stok \"Plastik Laminating A4\" sebanyak 32 (Restock)', '2026-07-24 04:14:11'),
(98, 1, 'Admin Lab', 'Barang Keluar', 'Mengeluarkan \"Plastik Laminating A4\" sebanyak 31 untuk Divisi Keuangan', '2026-08-01 00:10:31'),
(99, 1, 'Admin Lab', 'Tambah Barang', 'Menambah barang \"Buku Kwitansi\" (stok awal via seeding)', '2026-05-29 12:35:28'),
(100, 1, 'Admin Lab', 'Barang Masuk', 'Menambah stok \"Buku Kwitansi\" sebanyak 107 (Stok awal)', '2026-05-29 14:27:45'),
(101, 1, 'Admin Lab', 'Barang Keluar', 'Mengeluarkan \"Buku Kwitansi\" sebanyak 5 untuk Pelanggan', '2026-06-14 03:37:49'),
(102, 1, 'Admin Lab', 'Barang Keluar', 'Mengeluarkan \"Buku Kwitansi\" sebanyak 29 untuk Admin Kantor', '2026-06-17 20:09:33'),
(103, 1, 'Admin Lab', 'Barang Masuk', 'Menambah stok \"Buku Kwitansi\" sebanyak 58 (Restock)', '2026-06-23 20:33:08'),
(104, 1, 'Admin Lab', 'Barang Keluar', 'Mengeluarkan \"Buku Kwitansi\" sebanyak 13 untuk Admin Kantor', '2026-07-23 04:12:34'),
(105, 1, 'Admin Lab', 'Tambah Barang', 'Menambah barang \"Klip Kertas\" (stok awal via seeding)', '2026-06-13 12:35:28'),
(106, 1, 'Admin Lab', 'Barang Masuk', 'Menambah stok \"Klip Kertas\" sebanyak 122 (Stok awal)', '2026-06-13 14:26:33'),
(107, 1, 'Admin Lab', 'Barang Masuk', 'Menambah stok \"Klip Kertas\" sebanyak 61 (Restock)', '2026-06-28 00:22:23'),
(108, 1, 'Admin Lab', 'Barang Keluar', 'Mengeluarkan \"Klip Kertas\" sebanyak 20 untuk Bagian Umum', '2026-07-03 22:28:12'),
(109, 1, 'Admin Lab', 'Barang Keluar', 'Mengeluarkan \"Klip Kertas\" sebanyak 33 untuk Divisi HRD', '2026-07-18 21:47:45'),
(110, 1, 'Admin Lab', 'Tambah Barang', 'Menambah barang \"Binder Clip Besar\" (stok awal via seeding)', '2026-06-21 12:35:28'),
(111, 1, 'Admin Lab', 'Barang Masuk', 'Menambah stok \"Binder Clip Besar\" sebanyak 212 (Stok awal)', '2026-06-21 14:27:21'),
(112, 1, 'Admin Lab', 'Barang Keluar', 'Mengeluarkan \"Binder Clip Besar\" sebanyak 40 untuk Divisi Keuangan', '2026-06-26 02:53:27'),
(113, 1, 'Admin Lab', 'Barang Keluar', 'Mengeluarkan \"Binder Clip Besar\" sebanyak 8 untuk Pelanggan', '2026-07-17 22:51:38'),
(114, 1, 'Admin Lab', 'Barang Keluar', 'Mengeluarkan \"Binder Clip Besar\" sebanyak 34 untuk Ruang Rapat', '2026-07-18 00:34:37'),
(115, 1, 'Admin Lab', 'Barang Masuk', 'Menambah stok \"Binder Clip Besar\" sebanyak 57 (Restock)', '2026-07-20 01:20:54'),
(116, 1, 'Admin Lab', 'Login', 'Berhasil login', '2026-06-29 01:28:01'),
(117, 1, 'Admin Lab', 'Login', 'Berhasil login', '2026-07-20 20:47:07'),
(118, 1, 'Admin Lab', 'Login', 'Berhasil login', '2026-06-09 02:50:31'),
(119, 1, 'Admin Lab', 'Login', 'Berhasil login', '2026-06-09 03:51:46'),
(120, 1, 'Admin Lab', 'Login', 'Berhasil login', '2026-06-10 02:42:21'),
(121, 1, 'Admin Lab', 'Login', 'Berhasil login', '2026-06-10 04:04:00'),
(122, 1, 'Admin Lab', 'Login', 'Berhasil login', '2026-08-05 17:41:09'),
(123, 1, 'Admin Lab', 'Login', 'Berhasil login', '2026-08-05 18:32:47'),
(124, 1, 'Admin Lab', 'Login', 'Berhasil login', '2026-08-05 18:33:26'),
(125, 1, 'Admin Lab', 'Logout', 'Keluar dari sistem', '2026-08-05 18:34:28');

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `nama` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(20) NOT NULL DEFAULT 'admin',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `nama`, `email`, `password`, `role`, `created_at`) VALUES
(1, 'Admin Lab', 'Lab@gmail.com', '$2y$10$FxWVR0t3obZgZ8AsWhOPRu8hSBDap1eE2zFHYXaCoA3VxaMTpUjHu', 'admin', '2026-08-05 10:12:41');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `barang`
--
ALTER TABLE `barang`
  ADD PRIMARY KEY (`idbarang`);

--
-- Indeks untuk tabel `barang_keluar`
--
ALTER TABLE `barang_keluar`
  ADD PRIMARY KEY (`idkeluar`),
  ADD KEY `idbarang` (`idbarang`),
  ADD KEY `user_id` (`user_id`);

--
-- Indeks untuk tabel `barang_masuk`
--
ALTER TABLE `barang_masuk`
  ADD PRIMARY KEY (`idmasuk`),
  ADD KEY `idbarang` (`idbarang`),
  ADD KEY `user_id` (`user_id`);

--
-- Indeks untuk tabel `log_aktivitas`
--
ALTER TABLE `log_aktivitas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `barang`
--
ALTER TABLE `barang`
  MODIFY `idbarang` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT untuk tabel `barang_keluar`
--
ALTER TABLE `barang_keluar`
  MODIFY `idkeluar` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;

--
-- AUTO_INCREMENT untuk tabel `barang_masuk`
--
ALTER TABLE `barang_masuk`
  MODIFY `idmasuk` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT untuk tabel `log_aktivitas`
--
ALTER TABLE `log_aktivitas`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=126;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `barang_keluar`
--
ALTER TABLE `barang_keluar`
  ADD CONSTRAINT `fk_keluar_barang` FOREIGN KEY (`idbarang`) REFERENCES `barang` (`idbarang`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_keluar_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Ketidakleluasaan untuk tabel `barang_masuk`
--
ALTER TABLE `barang_masuk`
  ADD CONSTRAINT `fk_masuk_barang` FOREIGN KEY (`idbarang`) REFERENCES `barang` (`idbarang`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_masuk_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Ketidakleluasaan untuk tabel `log_aktivitas`
--
ALTER TABLE `log_aktivitas`
  ADD CONSTRAINT `fk_log_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
