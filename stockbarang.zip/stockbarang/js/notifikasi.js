/**
 * Notifikasi stok realtime: polling AJAX ke notifikasi.php tiap 10 detik,
 * update badge lonceng + dropdown di navbar.
 */
(function () {
    var POLL_INTERVAL = 10000; // 10 detik
    var badge = document.getElementById('notif-badge');
    var list = document.getElementById('notif-list');

    if (!badge || !list) return;

    function render(data) {
        if (data.count > 0) {
            badge.style.display = 'inline-block';
            badge.textContent = data.count;
        } else {
            badge.style.display = 'none';
            badge.textContent = '0';
        }

        if (data.items.length === 0) {
            list.innerHTML = '<span class="dropdown-item text-muted small">Semua stok aman.</span>';
            return;
        }

        var html = '';
        data.items.forEach(function (item) {
            var badgeClass = item.status === 'habis' ? 'badge-danger' : 'badge-warning';
            var badgeText = item.status === 'habis' ? 'HABIS' : 'MENIPIS';
            html +=
                '<a href="dashboard.php" class="dropdown-item d-flex justify-content-between align-items-center">' +
                '<span>' + item.nama + '</span>' +
                '<span class="badge ' + badgeClass + '">' + badgeText + ' (' + item.stock + ')</span>' +
                '</a>';
        });
        list.innerHTML = html;
    }

    function poll() {
        fetch('notifikasi.php', { credentials: 'same-origin' })
            .then(function (res) { return res.ok ? res.json() : Promise.reject(); })
            .then(render)
            .catch(function () { /* diamkan kalau gagal, coba lagi di interval berikutnya */ });
    }

    poll();
    setInterval(poll, POLL_INTERVAL);
})();
