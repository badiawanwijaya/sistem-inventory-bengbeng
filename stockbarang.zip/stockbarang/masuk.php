<?php
require 'config.php';
requireLogin();
require 'actions.php';

$pageTitle  = 'Barang Masuk';
$activeMenu = 'masuk';

$dataMasuk = $pdo->query(
    'SELECT m.idmasuk, m.idbarang, m.tanggal, m.qty, m.keterangan, b.namabarang
     FROM barang_masuk m
     JOIN barang b ON b.idbarang = m.idbarang
     ORDER BY m.tanggal DESC, m.idmasuk DESC'
)->fetchAll();

$daftarBarang = $pdo->query('SELECT idbarang, namabarang FROM barang ORDER BY namabarang ASC')->fetchAll();

require 'partials/header.php';
?>

<div class="card mb-4">
    <div class="card-header">
        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">
            <i class="fas fa-plus mr-1"></i>Tambah Barang Masuk
        </button>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>Tanggal</th>
                        <th>Nama Barang</th>
                        <th>Jumlah</th>
                        <th>Keterangan</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($dataMasuk as $data): ?>
                    <?php $idm = $data['idmasuk']; ?>
                    <tr>
                        <td><?= h($data['tanggal']) ?></td>
                        <td><?= h($data['namabarang']) ?></td>
                        <td><?= $data['qty'] ?></td>
                        <td><?= h($data['keterangan']) ?></td>
                        <td>
                            <button type="button" class="btn btn-warning" data-toggle="modal" data-target="#edit<?= $idm ?>">Edit</button>
                            <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#delete<?= $idm ?>">Delete</button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal Edit/Delete per transaksi (di luar <table> supaya HTML tetap valid & DataTables tidak rusak) -->
<?php foreach ($dataMasuk as $data): ?>
<?php $idb = $data['idbarang']; $idm = $data['idmasuk']; ?>
<div class="modal fade" id="edit<?= $idm ?>">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Edit Barang Masuk</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <form method="post">
                <div class="modal-body">
                    <label class="small mb-1">Keterangan</label>
                    <input type="text" name="keterangan" value="<?= h($data['keterangan']) ?>" class="form-control" required>
                    <label class="small mb-1 mt-2">Jumlah</label>
                    <input type="number" name="qty" value="<?= $data['qty'] ?>" class="form-control" required min="1">
                    <input type="hidden" name="idb" value="<?= $idb ?>">
                    <input type="hidden" name="idm" value="<?= $idm ?>">
                    <button type="submit" class="btn btn-primary mt-3" name="updatebarangmasuk">Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="delete<?= $idm ?>">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Hapus Data?</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <form method="post">
                <div class="modal-body">
                    Apakah Anda yakin ingin menghapus transaksi masuk <?= h($data['namabarang']) ?> (<?= $data['qty'] ?>)? Stok akan dikurangi kembali.
                    <input type="hidden" name="idb" value="<?= $idb ?>">
                    <input type="hidden" name="kty" value="<?= $data['qty'] ?>">
                    <input type="hidden" name="idm" value="<?= $idm ?>">
                    <br><br>
                    <button type="submit" class="btn btn-danger" name="hapusbarangmasuk">Hapus</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endforeach; ?>

<!-- Modal Tambah -->
<div class="modal fade" id="myModal">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Tambah Barang Masuk</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <form method="post">
                <div class="modal-body">
                    <select name="barangnya" class="form-control" required>
                        <?php if (empty($daftarBarang)): ?>
                        <option value="" disabled selected>Belum ada barang, tambahkan dulu di Dashboard</option>
                        <?php endif; ?>
                        <?php foreach ($daftarBarang as $b): ?>
                        <option value="<?= $b['idbarang'] ?>"><?= h($b['namabarang']) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <br>
                    <input type="number" name="qty" class="form-control" placeholder="Quantity" required min="1">
                    <br>
                    <input type="text" name="penerima" class="form-control" placeholder="Keterangan (mis. Supplier)" required>
                    <br>
                    <button type="submit" class="btn btn-primary" name="barangmasuk">Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php require 'partials/footer.php'; ?>
