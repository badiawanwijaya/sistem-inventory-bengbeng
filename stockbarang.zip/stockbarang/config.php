<?php
/**
 * config.php
 * Koneksi database (PDO + prepared statements) & helper umum.
 * Pengganti function.php/cek.php lama yang pakai mysqli + query mentah.
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

const DB_HOST = 'localhost';
const DB_NAME = 'stockbarang';
const DB_USER = 'root';
const DB_PASS = '';

try {
    $pdo = new PDO(
        'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]
    );
} catch (PDOException $e) {
    die(
        '<div style="font-family:sans-serif;max-width:640px;margin:60px auto;padding:24px;'
        . 'border:1px solid #f5c2c7;background:#f8d7da;color:#842029;border-radius:8px">'
        . '<h2 style="margin-top:0">Koneksi database gagal</h2>'
        . '<p>Database <code>stockbarang</code> belum ada atau belum di-import.</p>'
        . '<p>Buka <b>phpMyAdmin</b> &rarr; tab <b>Import</b> &rarr; pilih file '
        . '<code>db_inventaris.sql</code> di folder project ini, lalu muat ulang halaman.</p>'
        . '<p style="color:#555;font-size:13px">Detail teknis: ' . htmlspecialchars($e->getMessage()) . '</p>'
        . '</div>'
    );
}

/** Escape output ke HTML dengan aman. */
function h($str)
{
    return htmlspecialchars((string) $str, ENT_QUOTES, 'UTF-8');
}

/** Pastikan user sudah login, kalau belum lempar ke halaman login. */
function requireLogin()
{
    if (empty($_SESSION['log'])) {
        header('Location: login.php');
        exit;
    }
}

function currentUserId()
{
    return $_SESSION['user_id'] ?? null;
}

function currentUserName()
{
    return $_SESSION['user_nama'] ?? 'Guest';
}

/** Catat satu baris ke log_aktivitas. */
function logAktivitas(PDO $pdo, string $aktivitas, string $keterangan = '')
{
    $stmt = $pdo->prepare(
        'INSERT INTO log_aktivitas (user_id, nama_user, aktivitas, keterangan) VALUES (?, ?, ?, ?)'
    );
    $stmt->execute([currentUserId(), currentUserName(), $aktivitas, $keterangan]);
}

/** Simpan pesan flash (alert) untuk ditampilkan setelah redirect. */
function setFlash(string $type, string $message)
{
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

/** Ambil & hapus pesan flash yang tersimpan. */
function getFlash()
{
    if (empty($_SESSION['flash'])) {
        return null;
    }
    $flash = $_SESSION['flash'];
    unset($_SESSION['flash']);
    return $flash;
}

/** Jumlah barang yang stoknya habis atau di bawah/at batas minimum. */
function getStokKritisCount(PDO $pdo): int
{
    $stmt = $pdo->query('SELECT COUNT(*) FROM barang WHERE stock <= stock_minimum');
    return (int) $stmt->fetchColumn();
}
