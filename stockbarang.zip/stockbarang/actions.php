<?php
/**
 * actions.php
 * Menangani semua POST (tambah/update/hapus) memakai PDO prepared statements
 * + transaksi, lalu redirect kembali dengan pesan flash.
 * Pengganti function.php lama (mysqli + query string mentah).
 *
 * Harus di-include SETELAH config.php + requireLogin() supaya aksi tulis
 * data tidak bisa dipicu tanpa login.
 */

// ---------- Tambah barang baru ----------
if (isset($_POST['addnewbarang'])) {
    $namabarang = trim($_POST['namabarang']);
    $deskripsi  = trim($_POST['deskripsi']);
    $satuan     = trim($_POST['satuan'] ?? 'Pcs') ?: 'Pcs';
    $stock      = (int) $_POST['stock'];
    $minimum    = max(0, (int) ($_POST['stock_minimum'] ?? 5));

    $stmt = $pdo->prepare(
        'INSERT INTO barang (namabarang, deskripsi, satuan, stock, stock_minimum) VALUES (?, ?, ?, ?, ?)'
    );
    $stmt->execute([$namabarang, $deskripsi, $satuan, $stock, $minimum]);

    logAktivitas($pdo, 'Tambah Barang', "Menambah barang \"$namabarang\" (stok awal: $stock)");
    setFlash('success', "Barang \"$namabarang\" berhasil ditambahkan.");
    header('Location: dashboard.php');
    exit;
}

// ---------- Update info barang ----------
if (isset($_POST['updatebarang'])) {
    $idb        = (int) $_POST['idb'];
    $namabarang = trim($_POST['namabarang']);
    $deskripsi  = trim($_POST['deskripsi']);
    $satuan     = trim($_POST['satuan'] ?? 'Pcs') ?: 'Pcs';
    $minimum    = max(0, (int) ($_POST['stock_minimum'] ?? 5));

    $stmt = $pdo->prepare(
        'UPDATE barang SET namabarang = ?, deskripsi = ?, satuan = ?, stock_minimum = ? WHERE idbarang = ?'
    );
    $stmt->execute([$namabarang, $deskripsi, $satuan, $minimum, $idb]);

    logAktivitas($pdo, 'Update Barang', "Mengubah data barang \"$namabarang\" (ID $idb)");
    setFlash('success', "Barang \"$namabarang\" berhasil diperbarui.");
    header('Location: dashboard.php');
    exit;
}

// ---------- Hapus barang ----------
if (isset($_POST['hapusbarang'])) {
    $idb = (int) $_POST['idb'];

    $nama = $pdo->prepare('SELECT namabarang FROM barang WHERE idbarang = ?');
    $nama->execute([$idb]);
    $namabarang = $nama->fetchColumn() ?: "ID $idb";

    $stmt = $pdo->prepare('DELETE FROM barang WHERE idbarang = ?');
    $stmt->execute([$idb]);

    logAktivitas($pdo, 'Hapus Barang', "Menghapus barang \"$namabarang\"");
    setFlash('success', "Barang \"$namabarang\" berhasil dihapus.");
    header('Location: dashboard.php');
    exit;
}

// ---------- Tambah barang masuk ----------
if (isset($_POST['barangmasuk'])) {
    $idbarang   = (int) $_POST['barangnya'];
    $keterangan = trim($_POST['penerima']);
    $qty        = (int) $_POST['qty'];

    if ($qty <= 0) {
        setFlash('danger', 'Jumlah harus lebih dari 0.');
        header('Location: masuk.php');
        exit;
    }

    $pdo->beginTransaction();
    try {
        $stmt = $pdo->prepare(
            'INSERT INTO barang_masuk (idbarang, keterangan, qty, user_id) VALUES (?, ?, ?, ?)'
        );
        $stmt->execute([$idbarang, $keterangan, $qty, currentUserId()]);

        $upd = $pdo->prepare('UPDATE barang SET stock = stock + ? WHERE idbarang = ?');
        $upd->execute([$qty, $idbarang]);

        $nama = $pdo->prepare('SELECT namabarang FROM barang WHERE idbarang = ?');
        $nama->execute([$idbarang]);
        $namabarang = $nama->fetchColumn() ?: "ID $idbarang";

        $pdo->commit();
        logAktivitas($pdo, 'Barang Masuk', "Menambah stok \"$namabarang\" sebanyak $qty ($keterangan)");
        setFlash('success', "Barang masuk untuk \"$namabarang\" ($qty) berhasil dicatat.");
    } catch (Exception $e) {
        $pdo->rollBack();
        setFlash('danger', 'Gagal menyimpan barang masuk.');
    }
    header('Location: masuk.php');
    exit;
}

// ---------- Update barang masuk ----------
if (isset($_POST['updatebarangmasuk'])) {
    $idb        = (int) $_POST['idb'];
    $idm        = (int) $_POST['idm'];
    $keterangan = trim($_POST['keterangan']);
    $qtyBaru    = (int) $_POST['qty'];

    $pdo->beginTransaction();
    try {
        $qtyLamaStmt = $pdo->prepare('SELECT qty FROM barang_masuk WHERE idmasuk = ?');
        $qtyLamaStmt->execute([$idm]);
        $qtyLama = (int) $qtyLamaStmt->fetchColumn();

        $selisih = $qtyBaru - $qtyLama; // positif = nambah stok, negatif = kurangi stok
        $upd = $pdo->prepare('UPDATE barang SET stock = stock + ? WHERE idbarang = ?');
        $upd->execute([$selisih, $idb]);

        $updM = $pdo->prepare('UPDATE barang_masuk SET qty = ?, keterangan = ? WHERE idmasuk = ?');
        $updM->execute([$qtyBaru, $keterangan, $idm]);

        $pdo->commit();
        logAktivitas($pdo, 'Update Barang Masuk', "Mengubah transaksi masuk ID $idm menjadi qty $qtyBaru");
        setFlash('success', 'Data barang masuk berhasil diperbarui.');
    } catch (Exception $e) {
        $pdo->rollBack();
        setFlash('danger', 'Gagal memperbarui barang masuk.');
    }
    header('Location: masuk.php');
    exit;
}

// ---------- Hapus barang masuk ----------
if (isset($_POST['hapusbarangmasuk'])) {
    $idb = (int) $_POST['idb'];
    $qty = (int) $_POST['kty'];
    $idm = (int) $_POST['idm'];

    $pdo->beginTransaction();
    try {
        $upd = $pdo->prepare('UPDATE barang SET stock = stock - ? WHERE idbarang = ?');
        $upd->execute([$qty, $idb]);

        $del = $pdo->prepare('DELETE FROM barang_masuk WHERE idmasuk = ?');
        $del->execute([$idm]);

        $pdo->commit();
        logAktivitas($pdo, 'Hapus Barang Masuk', "Menghapus transaksi masuk ID $idm (qty $qty)");
        setFlash('success', 'Data barang masuk berhasil dihapus.');
    } catch (Exception $e) {
        $pdo->rollBack();
        setFlash('danger', 'Gagal menghapus barang masuk.');
    }
    header('Location: masuk.php');
    exit;
}

// ---------- Tambah barang keluar ----------
if (isset($_POST['addbarangkeluar'])) {
    $idbarang = (int) $_POST['barangnya'];
    $penerima = trim($_POST['penerima']);
    $qty      = (int) $_POST['qty'];

    if ($qty <= 0) {
        setFlash('danger', 'Jumlah harus lebih dari 0.');
        header('Location: keluar.php');
        exit;
    }

    $pdo->beginTransaction();
    try {
        $cek = $pdo->prepare('SELECT namabarang, stock FROM barang WHERE idbarang = ? FOR UPDATE');
        $cek->execute([$idbarang]);
        $row = $cek->fetch();

        if (!$row || $row['stock'] < $qty) {
            $pdo->rollBack();
            setFlash('danger', 'Stok tidak mencukupi untuk transaksi ini.');
            header('Location: keluar.php');
            exit;
        }

        $stmt = $pdo->prepare(
            'INSERT INTO barang_keluar (idbarang, penerima, qty, user_id) VALUES (?, ?, ?, ?)'
        );
        $stmt->execute([$idbarang, $penerima, $qty, currentUserId()]);

        $upd = $pdo->prepare('UPDATE barang SET stock = stock - ? WHERE idbarang = ?');
        $upd->execute([$qty, $idbarang]);

        $pdo->commit();
        logAktivitas($pdo, 'Barang Keluar', "Mengeluarkan \"{$row['namabarang']}\" sebanyak $qty untuk $penerima");
        setFlash('success', "Barang keluar untuk \"{$row['namabarang']}\" ($qty) berhasil dicatat.");
    } catch (Exception $e) {
        $pdo->rollBack();
        setFlash('danger', 'Gagal menyimpan barang keluar.');
    }
    header('Location: keluar.php');
    exit;
}

// ---------- Update barang keluar ----------
if (isset($_POST['updatebarangkeluar'])) {
    $idb      = (int) $_POST['idb'];
    $idk      = (int) $_POST['idk'];
    $penerima = trim($_POST['penerima']);
    $qtyBaru  = (int) $_POST['qty'];

    $pdo->beginTransaction();
    try {
        $qtyLamaStmt = $pdo->prepare('SELECT qty FROM barang_keluar WHERE idkeluar = ?');
        $qtyLamaStmt->execute([$idk]);
        $qtyLama = (int) $qtyLamaStmt->fetchColumn();

        $selisih = $qtyBaru - $qtyLama; // positif = keluar lebih banyak -> stok berkurang lagi

        $cekStok = $pdo->prepare('SELECT stock FROM barang WHERE idbarang = ? FOR UPDATE');
        $cekStok->execute([$idb]);
        $stockSekarang = (int) $cekStok->fetchColumn();

        if ($stockSekarang - $selisih < 0) {
            $pdo->rollBack();
            setFlash('danger', 'Stok tidak mencukupi untuk perubahan ini.');
            header('Location: keluar.php');
            exit;
        }

        $upd = $pdo->prepare('UPDATE barang SET stock = stock - ? WHERE idbarang = ?');
        $upd->execute([$selisih, $idb]);

        $updK = $pdo->prepare('UPDATE barang_keluar SET qty = ?, penerima = ? WHERE idkeluar = ?');
        $updK->execute([$qtyBaru, $penerima, $idk]);

        $pdo->commit();
        logAktivitas($pdo, 'Update Barang Keluar', "Mengubah transaksi keluar ID $idk menjadi qty $qtyBaru");
        setFlash('success', 'Data barang keluar berhasil diperbarui.');
    } catch (Exception $e) {
        $pdo->rollBack();
        setFlash('danger', 'Gagal memperbarui barang keluar.');
    }
    header('Location: keluar.php');
    exit;
}

// ---------- Hapus barang keluar ----------
if (isset($_POST['hapusbarangkeluar'])) {
    $idb = (int) $_POST['idb'];
    $qty = (int) $_POST['kty'];
    $idk = (int) $_POST['idk'];

    $pdo->beginTransaction();
    try {
        $upd = $pdo->prepare('UPDATE barang SET stock = stock + ? WHERE idbarang = ?');
        $upd->execute([$qty, $idb]);

        $del = $pdo->prepare('DELETE FROM barang_keluar WHERE idkeluar = ?');
        $del->execute([$idk]);

        $pdo->commit();
        logAktivitas($pdo, 'Hapus Barang Keluar', "Menghapus transaksi keluar ID $idk (qty $qty)");
        setFlash('success', 'Data barang keluar berhasil dihapus.');
    } catch (Exception $e) {
        $pdo->rollBack();
        setFlash('danger', 'Gagal menghapus barang keluar.');
    }
    header('Location: keluar.php');
    exit;
}
