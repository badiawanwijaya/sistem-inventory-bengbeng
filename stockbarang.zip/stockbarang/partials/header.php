<?php
/**
 * partials/header.php
 * Layout bersama: <head>, topnav (dengan bel notifikasi realtime), sidebar.
 * Halaman yang meng-include file ini WAJIB set $pageTitle & $activeMenu
 * sebelumnya, dan sudah require config.php + requireLogin().
 */
$pageTitle   = $pageTitle ?? 'Inventaris Foto Kopi';
$activeMenu  = $activeMenu ?? '';
$flash       = getFlash();

function navClass(string $key, string $active): string
{
    return 'nav-link' . ($key === $active ? ' active' : '');
}
?>
<!DOCTYPE html>
<html lang="id">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title><?= h($pageTitle) ?> - Inventaris Foto Kopi</title>
        <link href="css/styles.css" rel="stylesheet" />
        <link href="css/custom.css" rel="stylesheet" />
        <link href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css" rel="stylesheet" crossorigin="anonymous" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/js/all.min.js" crossorigin="anonymous"></script>
    </head>
    <body class="sb-nav-fixed">
        <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
            <a class="navbar-brand" href="dashboard.php">Inventaris Foto Kopi</a>
            <button class="btn btn-link btn-sm order-1 order-lg-0" id="sidebarToggle" href="#"><i class="fas fa-bars"></i></button>

            <ul class="navbar-nav ml-auto mr-3">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="notifDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fas fa-bell"></i>
                        <span id="notif-badge" class="badge badge-danger" style="display:none;position:relative;top:-8px;">0</span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right shadow-lg" aria-labelledby="notifDropdown" style="min-width:320px;max-height:360px;overflow-y:auto;">
                        <h6 class="dropdown-header">Notifikasi Stok</h6>
                        <div id="notif-list">
                            <span class="dropdown-item text-muted small">Memuat...</span>
                        </div>
                    </div>
                </li>
                <li class="nav-item">
                    <span class="nav-link"><i class="fas fa-user-circle mr-1"></i><?= h(currentUserName()) ?></span>
                </li>
            </ul>
        </nav>
        <div id="layoutSidenav">
            <div id="layoutSidenav_nav">
                <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">
                            <a class="<?= navClass('dashboard', $activeMenu) ?>" href="dashboard.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Dashboard
                            </a>
                            <a class="<?= navClass('masuk', $activeMenu) ?>" href="masuk.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-dolly"></i></div>
                                Barang Masuk
                            </a>
                            <a class="<?= navClass('keluar', $activeMenu) ?>" href="keluar.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-truck-loading"></i></div>
                                Barang Keluar
                            </a>
                            <a class="<?= navClass('log', $activeMenu) ?>" href="log_aktivitas.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-history"></i></div>
                                Log Aktifitas
                            </a>
                            <a class="<?= navClass('prediksi', $activeMenu) ?>" href="prediksi.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-chart-line"></i></div>
                                Prediksi
                            </a>
                            <a class="nav-link" href="logout.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-sign-out-alt"></i></div>
                                Logout
                            </a>
                        </div>
                    </div>
                </nav>
            </div>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid">
                        <h1 class="mt-4"><?= h($pageTitle) ?></h1>

                        <?php if ($flash): ?>
                        <div class="alert alert-<?= h($flash['type']) ?> alert-dismissible fade show" role="alert">
                            <?= h($flash['message']) ?>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        </div>
                        <?php endif; ?>
